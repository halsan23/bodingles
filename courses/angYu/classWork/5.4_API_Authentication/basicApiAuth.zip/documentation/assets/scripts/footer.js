// Footer Construction
// ===========================================================================

// assign variable
const footer = document.querySelector("#app-footer");

// build Footer
footer.innerHTML = `
    <div>Website created by badDoggy</div>
    <div>|</div>
    <div>2024</div>
    <div>|</div>
    <div>&copy; All Rights Reserved</div>
`;